# Data dictionary

Fifteen CSV files. One brewery, 1 January 2025 to 30 June 2026. Every file opens
in Excel, Google Sheets or Numbers with no setup.

**The rule that makes this usable:** every file reconciles against every other
file. Sales never exceed what was packaged. Purchases are derived from the brew
schedule through the recipes. A tank holds one batch at a time. If you find a
contradiction, it is a finding, not a typo.

---

## Which file for which question

| You are sitting as | Start with |
|---|---|
| Brewer | `batches.csv`, `tank_occupancy.csv`, `recipes.csv` |
| Owner | `pos_sales.csv`, `wholesale_orders.csv`, `beers.csv` |
| Manager | `tanks.csv`, `capacity_limits.csv`, `roster.csv`, `tank_occupancy.csv` |
| Marketer | `social_posts.csv`, `footfall.csv`, `calendar.csv` |
| Raw material seller | `purchases.csv`, `materials.csv`, `recipes.csv` |

---

## beers.csv
One row per SKU. The master list, and the only file with the economics precomputed.

| Column | Meaning |
|---|---|
| `sku` | Two letter code used in every other file |
| `beer`, `style` | Name and style |
| `target_og`, `target_fg` | Target original and final gravity |
| `abv_pct`, `ibu` | Strength and bitterness |
| `tank_days` | Days a batch occupies a fermenter before the tank frees up |
| `batch_size_hl` | 20 hL for fast movers, 10 hL for slow ones |
| `cogs_per_litre_inr` | Ingredient and packaging cost per litre |
| `taproom_price_500ml_inr` | List price of a 500 ml pour |
| `taproom_price_per_litre_inr` | The same price expressed per litre |
| `wholesale_price_30l_keg_inr` | Trade price of a 30 L keg |
| `gross_margin_per_litre_inr` | Taproom price per litre minus cogs |
| `contribution_per_batch_inr` | Margin per litre times batch volume |
| `contribution_per_tank_day_inr` | **Contribution per batch divided by tank days.** The number most breweries never calculate |
| `requires_lagering_tank` | Whether it needs one of the three glycol tanks |

## batches.csv
One row per brew. 200 rows.

`batch_code`, `sku`, `beer`, `brew_date`, `package_date`, `tank`, `batch_size_hl`,
`og`, `fg`, `abv_pct`, `tank_days_planned`, `tank_days_actual`, `yeast_generation`,
`packaged_litres`, `loss_pct`, `notes`

- `tank_days_actual` exceeds `tank_days_planned` when something went wrong.
- `yeast_generation` runs 1 to 8, then the yeast is replaced. High generations
  ferment slower.
- `loss_pct` is volume lost between the fermenter and the keg.
- `notes` is where dumped batches, slow attenuation and transfer losses are
  recorded. Read it.

## tank_occupancy.csv
One row per batch, expressed as a **date interval**.

`batch_code`, `tank`, `sku`, `occupied_from`, `occupied_to`, `days`

Use an interval overlap to ask what was in which tank on a given date. Do not join
on a single date; a batch occupies its tank for weeks.

## tanks.csv
`tank_id`, `capacity_hl`, `lagering_capable`, `note`

Eight rows. Only three tanks can hold lagering temperature, which is the constraint
that decides what the brewery can and cannot plan.

## capacity_limits.csv
`asset`, `capacity`, `unit`, `note`

The physical ceilings: cold room keg slots, tap lines, keg fleet, bright tank. These
are the limits a model will cheerfully ignore unless you tell it they exist.

## recipes.csv
`sku`, `material_code`, `material`, `qty_per_hl`, `unit`

The bill of materials per hectolitre. **This is the file that connects the brewer's
plan to the supplier's forecast.** Change the production plan and this file tells you
exactly which raw material demand moves.

## materials.csv
`material_code`, `material`, `unit`, `unit_cost_inr`, `lead_time_days`, `bag_size`,
`supplier`, `purchased_to_date`, `consumed_to_date`, `closing_stock_2026_06_30`

Lead times matter more than price here. Imported malt and hops run 45 to 60 days.
Local fruit runs 7 to 10.

## purchases.csv
`po_number`, `order_date`, `expected_date`, `material_code`, `material`, `supplier`,
`quantity`, `unit`, `unit_cost_inr`, `line_total_inr`, `lead_time_days`,
`consumed_by_recipe_qty`

Every order was placed lead-time days before the brew it feeds, rounded up to whole
bags. `consumed_by_recipe_qty` is what the recipes actually needed, so the gap
between that and `quantity` is over-ordering.

## pos_sales.csv
Daily taproom sales by SKU. 3,000 plus rows.

`date`, `sku`, `beer`, `litres_sold`, `servings_500ml`, `list_price_500ml`,
`discount_pct`, `gross_revenue_inr`, `cogs_inr`

`discount_pct` covers the Tuesday and Wednesday happy hour, and the heavier
promotional push run in February to April 2026. Contribution is
`gross_revenue_inr` minus `cogs_inr`.

## wholesale_orders.csv
`date`, `account_id`, `account`, `sku`, `beer`, `kegs_30l`, `litres`,
`price_per_keg_inr`, `revenue_inr`, `cogs_inr`

Orders are placed Mondays and Thursdays across six accounts.

## footfall.csv
`date`, `weekday`, `covers`, `is_dry_day`, `festival`, `ipl_window`

One row per day for all 546 days. `covers` is people through the door. Dry days are
zero by law, not by choice.

## roster.csv
`date`, `weekday`, `bar_staff`, `kitchen_staff`, `brewery_staff`, `max_covers_served`

Monday, Tuesday and Wednesday run on **one** bar staff member. `max_covers_served`
is a rough service ceiling at that staffing level.

## social_posts.csv
`post_id`, `date`, `platform`, `post_type`, `reach`, `engagements`, `saves`,
`profile_taps`, `mentions_price_or_discount`, `mentions_alcohol_directly`

Six post types. The last two columns exist because Indian advertising rules restrict
direct alcohol promotion, and the best performing content is usually the content
that breaks them.

## calendar.csv
`date`, `dry_day`, `festival`, `ipl_window`

Only the dates that matter. 143 rows.

## stockouts.csv
`date`, `sku`, `unmet_litres`

Demand that existed when the beer did not. These were not scripted. They emerged
because the brewery ran out, which is what makes them worth reading.
