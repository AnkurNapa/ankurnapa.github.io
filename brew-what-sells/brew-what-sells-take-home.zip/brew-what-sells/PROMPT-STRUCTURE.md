# The four-line prompt structure

**This is the card you were handed at the start of the session.** Every prompt used
today is these four lines, in a different order, with a different file attached.

---

## The four lines

**1. The role and the decision.**
Tell it what job it is doing and what you are deciding. Not "analyse my sales."

> You are helping me plan next month's production at a craft brewery.

**2. The evidence, attached.**
Attach the file first, then say what is in it. Never describe your numbers in words
and hope it imagines them correctly.

> Attached are 18 months of taproom sales, brew records and the beer master list.

**3. The shape you want back.**
Name the columns. Name the order. Say how long. This is the line that saves you
from three paragraphs of commentary you did not ask for.

> Give me a table: beer, batches, litres, reason. Ranked by contribution per tank
> day. No commentary.

**4. The honesty clause.**
Without this it will fill a gap rather than admit to one.

> Tell me which numbers you are confident in and which are thin. If the history for
> a beer is too short to forecast, say so instead of guessing.

---

## The whole thing, ready to paste

```
You are helping me plan next month's production at a craft brewery.

Attached are 18 months of taproom sales, brew records and the beer master list.

Work out, for each beer: litres sold per month, the trend over the last six
months, and how many batches I need next month to cover demand plus three weeks
of cover.

Give me the answer as a table: beer, batches, litres, reason. Ranked. No
commentary.

Tell me which numbers you are confident in and which are thin. If the history for
a beer is too short or too seasonal to forecast, say so instead of guessing.
```

---

## Using it on your own numbers

Your column names will not match the ones in the take-home dataset. You do not need
to rename anything. Add one line:

> In my file, litres sold is called Qty_Ltr and the date column is TxnDate.

That is the entire mapping step. It reads the header row and works out the rest.

---

## Why each line is there

| Line | What it prevents |
|---|---|
| Role and decision | A generic summary of your data instead of an answer to your question |
| Evidence attached | Invention. If it is not reading your file, it is predicting plausible text |
| Shape you want back | An essay. You wanted six ranked rows |
| Honesty clause | A confident number sitting on three weeks of thin history |

---

## The one habit that matters most

**One thread per decision.** Not one per week, and not one per day. Keep August
production in its own thread with its own attached files. When August is decided,
close it. A thread carrying forty-nine earlier answers gets slower, more expensive
and less accurate at exactly the same time.

---

**Ankur Napa**
Growth Officer, Disruptive Advantage
napaankur@gmail.com | linkedin.com/in/ankur-napa
