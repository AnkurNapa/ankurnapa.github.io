# Data security, on one page

Nothing in this page is legal advice. It is the short list of habits that keep a
brewery out of trouble when it starts putting real numbers into an AI tool.

---

## The one test

Before any file goes up, ask yourself one question:

> **Would you be comfortable if this file turned up in a competitor's inbox?**

If the answer is no, find the column that makes it no and delete that column. It is
almost always a name. It is almost never a number.

Your sales quantities are commercially dull on their own. Your customer list is not.
Send the first, keep the second.

---

## Do

**Strip the personal columns before you upload.**
Customer names, phone numbers, email addresses, delivery addresses, staff names and
payroll. Quantities, prices, dates, batch numbers and tank days are all fine and are
all you need for every calculation in this session.

**Turn off training on your chats.**
Every serious tool has a setting that controls whether your conversations are used
to improve the model. Find it once, turn it off on any account that will see real
numbers, and check it again after any major update.

**Use a paid business account for business data.**
Free tiers are built for casual use and their data terms reflect that. If the
brewery's numbers are going in, the brewery should be paying for the account.

**One thread per decision, closed when the decision is made.**
It is cheaper, it is more accurate, and it means a single stale thread is not
carrying nine months of your commercial history.

**Read the output before it goes anywhere official.**
Anything heading for a filing, an excise return, a bank pack or a compliance
document gets read by a human first. Every time.

---

## Do not

**Do not paste bank details, GST portal logins, or any credential.**
There is no analysis that needs them.

**Do not upload a contract with a confidentiality clause in it.**
Your distribution agreement almost certainly restricts who you may share it with,
and an AI vendor is a third party.

**Do not use one shared brewery login.**
When something goes wrong you will not be able to tell who uploaded what, and you
cannot remove one person's access without changing everybody's password.

**Do not assume a deleted chat is deleted everywhere immediately.**
Deletion in the interface and deletion from every backup are different events, on
different timelines. Treat "I will delete it after" as no protection at all.

**Do not put your recipe IP into a shared workspace you do not control.**
Your grain bill is the one genuinely irreplaceable thing in the building.

---

## The three-minute setup

Do this once, this week, before you upload anything real.

1. Open your account settings and turn off training on your chats.
2. Create one account per person who will use it. No shared logins.
3. Make a copy of your POS export, delete the customer name and phone columns from
   the copy, and save it as `export-safe.csv`. Upload that copy, never the original.

Step three takes about ninety seconds and removes most of the risk on this page.

---

**Ankur Napa**
Growth Officer, Disruptive Advantage
napaankur@gmail.com | linkedin.com/in/ankur-napa
