# Deccan Draught Co.

**The brewery every demo in this workshop runs against.**

> This brewery is not real. Every number in it is. It was built from Brewers
> Association operating benchmarks and 250 real recipes so it behaves like yours,
> and because it is not real, you get to see its bad months.

---

## The brewery

| | |
|---|---|
| **Location** | Pune, Maharashtra |
| **Age** | Year four |
| **Taps** | 8 |
| **Channel mix** | 64 percent taproom, 36 percent wholesale |
| **Brewhouse** | 10 hL, up to 3 double brews per week |
| **Fermenters** | 8 total. FV1 to FV6 at 20 hL, FV7 and FV8 at 10 hL |
| **Lagering capable** | FV1, FV2, FV3 only. Glycol jacket, holds 4 C |
| **Bright tank** | One, 20 hL |
| **Cold room** | 14 keg slots (30 L kegs) |
| **Keg fleet** | 96 owned, roughly 40 out with accounts at any time |
| **Wholesale accounts** | 6, across Pune and Lonavala |

## The period covered

**1 January 2025 to 30 June 2026.** Eighteen months, daily granularity.

The decision the workshop makes is for **August 2026**, so everything in the data
is history you are allowed to learn from.

## The range

| SKU | Beer | Style | ABV | Tank days | Volume sold |
|---|---|---|---|---|---|
| DL | Deccan Lager | Helles Lager | 4.9 | 28 | 73,249 L |
| SW | Sahyadri Wheat | Hefeweizen | 5.0 | 12 | 68,110 L |
| GI | Ghat Road IPA | West Coast IPA | 6.3 | 16 | 49,798 L |
| PP | Peninsular Pale | Pale Ale | 4.9 | 14 | 35,275 L |
| MS | Monsoon Stout | Dry Stout | 5.5 | 18 | 23,722 L |
| KS | Kokum Sour | Fruited Sour | 5.0 | 16 | 15,941 L |
| HH | Hapus Hazy | Mango Hazy IPA | 5.6 | 14 | 14,159 L |

Hapus Hazy is a seasonal, brewed for March to May only.

## What the 18 months contain

- **200 batches**, one of which was dumped
- **280,254 litres** sold across both channels
- **INR 11.97 crore** of gross revenue
- **293 recorded stockout events**, where demand existed and beer did not
- A **monsoon trough** every year. The worst month for contribution is July 2025
  at INR 42.4 lakh; the best is May 2026 at INR 74.2 lakh. A 2.3x swing.
- A **February 2026 wobble**: the glycol compressor was down from 5 to 26
  February, so no lager could be started, and batch B2602141 of Kokum Sour was
  dumped on 2 February after a lactic infection.
- **Dry days, festivals and the IPL window**, because in India those move beer
  more than the weather does.

## The bad months are the point

A real brewery would never let you put its thin margins, its dumped batch and its
stockouts on a screen in front of a room. That is exactly why this brewery is
fictional. Everything embarrassing has been left in.

## Honest limitations

Worth knowing before you draw conclusions and take them home:

- **Costs are beer costs only.** No rent, salaries, electricity, excise or licence
  fees. Contribution per litre here is not profit.
- **No food or merchandise revenue.** A real brewpub earns a large share of its
  money from the kitchen, and that is absent.
- **One brewery, one city.** Pune seasonality and Maharashtra dry days are baked
  in. Bengaluru or Goa would look different.
- **Prices are static** across the whole 18 months. No price rises, no input
  inflation.
- **Demand is modelled, not observed.** It follows benchmark-shaped seasonality
  and a growth curve, so it is realistic in shape rather than true in detail.
