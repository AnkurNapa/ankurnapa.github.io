"""Deccan Draught Co. - synthetic brewery dataset for the workshop.

One brewery, one 18 month period, five seats that must reconcile:

    brewer   -> batches.csv, tank_occupancy.csv, recipes.csv
    owner    -> pos_sales.csv, wholesale_orders.csv, beers.csv
    manager  -> tanks.csv, tank_occupancy.csv, roster.csv, keg_inventory.csv
    marketer -> social_posts.csv, footfall.csv, calendar.csv
    supplier -> purchases.csv, materials.csv, recipes.csv

Reconciliation rules enforced by construction:
  1. Sales can never exceed packaged volume. Stockouts are emergent, not scripted.
  2. A tank holds exactly one batch at a time. Occupancy is stored as an interval.
  3. Raw material purchases are derived from the brew schedule via recipes.csv,
     placed lead-time days ahead of the brew date, in whole bags.
  4. Footfall follows taproom revenue at a modelled average spend, lifted by
     social posts and the India calendar (dry days, festivals, IPL).

Deterministic: seeded. Re-running produces byte-identical CSVs.

Run:  _pptx_venv/bin/python "Beer/Brew What Sells with AI/build_dataset.py"

Numbers are grounded in Brewers Association operating benchmarks and Indian
craft pricing. The brewery is fictional. See DATA-DICTIONARY.md.
"""
import csv
import os
from typing import List, NamedTuple, Optional
import random
from datetime import date, timedelta

SEED = 20260730
random.seed(SEED)

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "dataset")
os.makedirs(OUT, exist_ok=True)

START = date(2025, 1, 1)
END = date(2026, 6, 30)
PLAN_MONTH = "2026-08"          # the decision the workshop makes

# ---------------------------------------------------------------------------
# Masters
# ---------------------------------------------------------------------------

# tank_days = fermentation + conditioning before the tank frees up.
# Deccan Lager needs cold conditioning, which is the scarce-resource story.
class Beer(NamedTuple):
    """One SKU. Named fields on purpose: positional access caused a bug where
    ibu was read as tank_days and cogs was read as the taproom price."""
    code: str
    name: str
    style: str
    og: float
    fg: float
    abv: float
    ibu: int
    tank_days: int
    cogs_l: float
    pint_500: int
    keg_30l: int


_BEER_ROWS = [
    # code name                 style           og     fg     abv ibu tank_days cogs_l  pint_500 keg_30l
    ("DL", "Deccan Lager",      "Helles Lager", 1.048, 1.010, 4.9, 20, 28, 44.0, 260, 5400),
    ("SW", "Sahyadri Wheat",    "Hefeweizen",   1.050, 1.012, 5.0, 12, 12, 38.0, 280, 6000),
    ("GI", "Ghat Road IPA",     "West Coast IPA", 1.062, 1.014, 6.3, 55, 16, 52.0, 320, 6600),
    ("PP", "Peninsular Pale",   "Pale Ale",     1.048, 1.011, 4.9, 32, 14, 40.0, 270, 5700),
    ("MS", "Monsoon Stout",     "Dry Stout",    1.058, 1.016, 5.5, 35, 18, 50.0, 310, 6300),
    ("KS", "Kokum Sour",        "Fruited Sour", 1.044, 1.006, 5.0,  6, 16, 66.0, 360, 7200),
    ("HH", "Hapus Hazy",        "Mango Hazy IPA", 1.055, 1.012, 5.6, 25, 14, 58.0, 340, 6900),
]
BEERS = [Beer(*r) for r in _BEER_ROWS]
BEER = {b.code: b for b in BEERS}

# Only FV1 to FV3 have the glycol capacity to hold lagering temperature.
# That is 3 of 8 fermenters reserved for one slow, low-margin SKU.
TANKS = [
    ("FV1", 20, "yes"), ("FV2", 20, "yes"), ("FV3", 20, "yes"),
    ("FV4", 20, "no"), ("FV5", 20, "no"), ("FV6", 20, "no"),
    ("FV7", 10, "no"), ("FV8", 10, "no"),
]
LAGER_TANKS = {t[0] for t in TANKS if t[2] == "yes"}
TANK_CAP = {t[0]: t[1] for t in TANKS}

# material_code, name, unit, unit_cost, lead_time_days, bag_size, supplier
MATERIALS = [
    ("M-PILS", "Pilsner malt",      "kg", 78.0, 45, 25, "Weyermann via Pune importer"),
    ("M-WHEAT", "Wheat malt",       "kg", 82.0, 45, 25, "Weyermann via Pune importer"),
    ("M-PALE", "Pale ale malt",     "kg", 64.0, 14, 25, "Barmalt India"),
    ("M-CRYS", "Crystal 60 malt",   "kg", 96.0, 21, 25, "Barmalt India"),
    ("M-CHOC", "Chocolate malt",    "kg", 108.0, 21, 25, "Barmalt India"),
    ("M-ROAST", "Roasted barley",   "kg", 92.0, 21, 25, "Barmalt India"),
    ("H-HALL", "Hallertau Mittelfruh", "g", 3.20, 60, 5000, "Yakima via Mumbai"),
    ("H-CITRA", "Citra",            "g", 5.80, 60, 5000, "Yakima via Mumbai"),
    ("H-MOSAIC", "Mosaic",          "g", 5.40, 60, 5000, "Yakima via Mumbai"),
    ("H-CASC", "Cascade",           "g", 3.90, 45, 5000, "Yakima via Mumbai"),
    ("H-FUGG", "Fuggles",           "g", 3.60, 45, 5000, "Yakima via Mumbai"),
    ("A-KOKUM", "Kokum fruit pulp", "kg", 145.0, 7, 10, "Ratnagiri co-op"),
    ("A-MANGO", "Alphonso puree",   "kg", 168.0, 10, 20, "Ratnagiri co-op"),
    ("Y-LAGER", "Lager yeast pitch", "ea", 4200.0, 30, 1, "Lallemand India"),
    ("Y-ALE", "Ale yeast pitch",    "ea", 3600.0, 30, 1, "Lallemand India"),
]
MAT = {m[0]: m for m in MATERIALS}

# Bill of materials per hectolitre.
RECIPES = {
    "DL": [("M-PILS", 16.0), ("H-HALL", 90.0)],
    "SW": [("M-WHEAT", 8.5), ("M-PILS", 8.5), ("H-HALL", 40.0)],
    "GI": [("M-PALE", 18.0), ("M-CRYS", 1.5), ("H-CITRA", 180.0), ("H-MOSAIC", 120.0)],
    "PP": [("M-PALE", 15.0), ("M-CRYS", 1.0), ("H-CASC", 110.0)],
    "MS": [("M-PALE", 14.0), ("M-ROAST", 2.0), ("M-CHOC", 1.5), ("H-FUGG", 90.0)],
    "KS": [("M-PILS", 12.0), ("M-WHEAT", 3.0), ("A-KOKUM", 6.0), ("H-HALL", 15.0)],
    "HH": [("M-PALE", 15.0), ("M-WHEAT", 3.0), ("A-MANGO", 8.0), ("H-CITRA", 90.0)],
}

# ---------------------------------------------------------------------------
# India calendar: dry days, festivals, IPL. Drives demand, not decoration.
# ---------------------------------------------------------------------------
DRY_DAYS = {
    date(2025, 1, 26), date(2025, 8, 15), date(2025, 10, 2), date(2025, 4, 10),
    date(2025, 9, 5), date(2026, 1, 26), date(2026, 3, 4), date(2026, 4, 30),
}
FESTIVALS = {
    date(2025, 3, 14): "Holi", date(2025, 8, 27): "Ganesh Chaturthi",
    date(2025, 10, 20): "Diwali", date(2025, 12, 31): "New Year Eve",
    date(2026, 3, 3): "Holi", date(2026, 9, 15): "Ganesh Chaturthi",
    date(2025, 12, 25): "Christmas", date(2026, 6, 21): "Monsoon Fest",
}
IPL_WINDOWS = [(date(2025, 3, 22), date(2025, 5, 25)), (date(2026, 3, 21), date(2026, 5, 24))]


def is_ipl(d: date) -> bool:
    return any(a <= d <= b for a, b in IPL_WINDOWS)


def month_key(d: date) -> str:
    return f"{d.year:04d}-{d.month:02d}"


def months(start, end):
    out, y, m = [], start.year, start.month
    while (y, m) <= (end.year, end.month):
        out.append(f"{y:04d}-{m:02d}")
        m += 1
        if m == 13:
            y, m = y + 1, 1
    return out


ALL_MONTHS = months(START, END)

# Seasonality: Pune monsoon (Jun-Sep) suppresses taproom, winter and festivals lift.
SEASON = {1: 1.05, 2: 1.02, 3: 1.12, 4: 1.15, 5: 1.10, 6: 0.82,
          7: 0.74, 8: 0.78, 9: 0.88, 10: 1.18, 11: 1.14, 12: 1.22}

# Channel split from the brewery fact sheet: 60 percent taproom, 40 wholesale.
TAPROOM_SHARE = 0.60
WHOLESALE_SHARE = 0.40

# Base monthly taproom demand in litres, year 4 brewery, 8 taps.
BASE_DEMAND_L = {"DL": 2600, "SW": 2100, "GI": 1500, "PP": 1050,
                 "MS": 700, "KS": 470, "HH": 0}
# Hapus Hazy is a mango seasonal: Mar to May only.
HH_MONTHS = {3, 4, 5}

# Growth: the brewery is growing, then flattens after the Feb 2026 wobble.
def growth(mk: str) -> float:
    # look-ahead during brew planning can run past the period, so clamp
    i = ALL_MONTHS.index(mk) if mk in ALL_MONTHS else len(ALL_MONTHS) - 1
    if i <= 13:
        return 1.0 + 0.011 * i
    return 1.0 + 0.011 * 13 - 0.004 * (i - 13)


def demand_litres(code: str, mk: str) -> float:
    y, m = int(mk[:4]), int(mk[5:])
    if code == "HH":
        base = 1400 if m in HH_MONTHS else 0
    else:
        base = BASE_DEMAND_L[code]
    if base == 0:
        return 0
    return base * SEASON[m] * growth(mk)


# ---------------------------------------------------------------------------
# Single day-by-day simulation: brew decisions react to real stock and real
# sales, so inventory behaves like a brewery instead of a spreadsheet.
# Brewing against days-of-cover is what makes stockouts and tank contention
# EMERGENT rather than scripted.
# ---------------------------------------------------------------------------
batches = []
occupancy = []
tank_free = {t[0]: START for t in TANKS}
yeast_gen = {"DL": 1, "SW": 1, "GI": 1, "PP": 1, "MS": 1, "KS": 1, "HH": 1}
batch_seq = 0

COMPRESSOR_DOWN = (date(2026, 2, 5), date(2026, 2, 26))
DUMPED = set()

MAX_BREW_DAYS_WEEK = 6       # 10 hL brewhouse, 3 double brews per week

# Fast movers fill a 20 hL fermenter (a double brew). Slow movers go into the
# 10 hL tanks, because a 20 hL batch of a slow mover is 50+ days of cover and
# the beer ages out before it sells.
BIG_BATCH = {"DL", "SW", "GI"}


def brew_volume(code: str) -> int:
    """Batch size in hL. 20 hL is a double brew on the 10 hL brewhouse."""
    return 20 if code in BIG_BATCH else 10


def reorder_point_days(code: str) -> int:
    """Cover level that triggers a brew: tank time plus a week of safety.

    A beer needing 28 tank-days cannot be reordered at 20 days of cover; it
    would be dry for a week before the new batch lands. This is why Deccan
    Lager stocks out even though it is the bestseller.
    """
    return BEER[code].tank_days + 7


def daily_demand(code: str, d: date) -> float:
    """Total daily demand (taproom + wholesale) in litres, for cover maths."""
    md = demand_litres(code, month_key(d))
    if md <= 0:
        return 0.0
    dim = (date(d.year + (d.month // 12), d.month % 12 + 1, 1) - timedelta(days=1)).day
    return (md / TAPROOM_SHARE) / dim


def try_brew(code: str, d: date) -> bool:
    """Schedule one batch of `code` starting on d if a legal tank is free."""
    global batch_seq
    td = BEER[code].tank_days
    vol = brew_volume(code)
    needs_lager_tank = (code == "DL")
    if needs_lager_tank and COMPRESSOR_DOWN[0] <= d <= COMPRESSOR_DOWN[1]:
        return False

    cands = [t for t in TANK_CAP if TANK_CAP[t] >= vol and tank_free[t] <= d]
    if needs_lager_tank:
        cands = [t for t in cands if t in LAGER_TANKS]
    if not cands:
        return False
    tank = sorted(cands)[0]

    pkg = d + timedelta(days=td)
    batch_seq += 1
    bc = f"B{d.year % 100:02d}{d.month:02d}{batch_seq:03d}"

    g = yeast_gen[code]
    yeast_gen[code] = 1 if g >= 8 else g + 1

    og = BEER[code].og + random.choice([-0.001, 0, 0, 0.001])
    fg = BEER[code].fg + random.choice([-0.001, 0, 0, 0.001])
    abv = round((og - fg) * 131.25, 1)
    loss = random.uniform(0.03, 0.07)
    packaged = round(vol * 100 * (1 - loss))

    note = ""
    if code == "KS" and d >= date(2026, 2, 1) and not DUMPED:
        note = "DUMPED: lactic infection, pediococcus confirmed"
        DUMPED.add(bc)
        packaged = 0
    elif g >= 7 and code == "DL":
        note = f"yeast generation {g}, attenuation slow, held 3 extra days"
        pkg = pkg + timedelta(days=3)
    elif loss > 0.065:
        note = "high transfer loss, trub carryover"

    batches.append({
        "batch_code": bc, "sku": code, "beer": BEER[code].name,
        "brew_date": d.isoformat(), "package_date": pkg.isoformat(),
        "tank": tank, "batch_size_hl": vol,
        "og": round(og, 3), "fg": round(fg, 3), "abv_pct": abv,
        "tank_days_planned": td, "tank_days_actual": (pkg - d).days,
        "yeast_generation": g, "packaged_litres": packaged,
        "loss_pct": round(loss * 100, 1), "notes": note,
    })
    occupancy.append({
        "batch_code": bc, "tank": tank, "sku": code,
        "occupied_from": d.isoformat(), "occupied_to": pkg.isoformat(),
        "days": (pkg - d).days,
    })
    tank_free[tank] = pkg + timedelta(days=1)     # 1 day CIP turnaround
    return True


arrivals = {}

# Deccan Draught is in its fourth year, so it does NOT start with empty tanks.
# Without opening inventory the first month looks like a failing brewery and the
# whole seasonality read is distorted by a startup artifact.
stock = {}
for _c in BEER:
    _md = demand_litres(_c, ALL_MONTHS[0])
    stock[_c] = round((_md / TAPROOM_SHARE) / 31 * 18, 0) if _md else 0.0
OPENING_STOCK = dict(stock)
pos_rows, ws_rows, footfall_rows, stockouts = [], [], [], []

WEEKDAY_W = {0: 0.72, 1: 0.70, 2: 0.80, 3: 0.95, 4: 1.45, 5: 1.75, 6: 1.30}

# wholesale accounts
ACCOUNTS = [("A01", "Koregaon Park Gastropub"), ("A02", "Baner Sports Bar"),
            ("A03", "Viman Nagar Bistro"), ("A04", "Kalyani Nagar Taproom"),
            ("A05", "Hinjewadi Food Court"), ("A06", "Lonavala Resort")]

d = START
brew_days_this_week = 0
while d <= END:
    if d.weekday() == 0:
        brew_days_this_week = 0

    # beer packaged today lands in stock today
    for b in batches:
        if b["package_date"] == d.isoformat():
            stock[b["sku"]] += b["packaged_litres"]

    # --- brew decision: react to days of cover, not to a fixed plan ---------
    if d.weekday() < 5 and brew_days_this_week < MAX_BREW_DAYS_WEEK:
        cover = []
        for code in BEER:
            dd = daily_demand(code, d)
            # seasonal: only build Hapus Hazy stock from February
            if code == "HH" and d.month not in (2, 3, 4, 5):
                continue
            if dd <= 0:
                continue
            # look ahead: will it still be selling by the time this batch lands?
            ahead = d + timedelta(days=BEER[code].tank_days)
            if demand_litres(code, month_key(ahead)) <= 0:
                continue
            wip = sum(b["packaged_litres"] for b in batches
                      if b["sku"] == code and b["package_date"] > d.isoformat())
            days_cover = (stock[code] + wip) / dd if dd else 999
            # rank by urgency against each beer's own reorder point
            cover.append((days_cover - reorder_point_days(code), days_cover, code))
        cover.sort()
        for slack, days_cover, code in cover:
            if slack >= 0:
                break
            if try_brew(code, d):
                brew_days_this_week += 1
                if brew_volume(code) == 20:
                    brew_days_this_week += 1      # double brew costs two days
                break

    mk = month_key(d)
    dim = (date(d.year + (d.month // 12), d.month % 12 + 1, 1) - timedelta(days=1)).day
    dry = d in DRY_DAYS
    fest = FESTIVALS.get(d)
    ipl = is_ipl(d) and d.weekday() in (4, 5, 6)

    day_mult = WEEKDAY_W[d.weekday()]
    if fest:
        day_mult *= 1.55
    if ipl:
        day_mult *= 1.22
    if dry:
        day_mult = 0.0

    day_covers = 0
    for sku in BEER:
        md = demand_litres(sku, mk)
        if md <= 0:
            continue
        want = md / dim * day_mult * random.uniform(0.88, 1.12)
        got = min(want, stock[sku])
        if want - got > 1.0 and not dry:
            stockouts.append({"date": d.isoformat(), "sku": sku,
                              "unmet_litres": round(want - got, 1)})
        if got <= 0:
            continue
        stock[sku] -= got
        price_500 = BEER[sku].pint_500
        pints = got / 0.5
        # discounting: Tue/Wed happy hour, and the 2026 price-promo push
        disc = 0.0
        if d.weekday() in (1, 2):
            disc = 0.20
        if d.year == 2026 and d.month in (2, 3, 4) and d.weekday() in (1, 2, 3):
            disc = 0.30
        gross = pints * price_500 * (1 - disc)
        pos_rows.append({
            "date": d.isoformat(), "sku": sku, "beer": BEER[sku].name,
            "litres_sold": round(got, 1), "servings_500ml": round(pints, 1),
            "list_price_500ml": price_500, "discount_pct": int(disc * 100),
            "gross_revenue_inr": round(gross, 0),
            "cogs_inr": round(got * BEER[sku].cogs_l, 0),
        })
        day_covers += pints / 2.35     # ~2.35 servings per cover

    # Wholesale draws on the SAME demand model as the taproom, at the 40/60 split
    # in the brief. Generating it independently made the channel mix come out
    # 88/12, which contradicted the brewery fact sheet.
    if d.weekday() in (0, 3) and not dry:
        for sku in BEER:
            md = demand_litres(sku, mk)
            if md <= 0:
                continue
            monthly_ws = md * (WHOLESALE_SHARE / TAPROOM_SHARE)
            per_order_day = monthly_ws / (dim / 7 * 2)      # Mon and Thu only
            kegs = int(round(per_order_day / 30 * random.uniform(0.8, 1.2)))
            if kegs <= 0:
                continue
            # split the day's kegs across a few accounts
            picks = random.sample(ACCOUNTS, min(len(ACCOUNTS), max(1, min(3, kegs))))
            for i, (acc, accname) in enumerate(picks):
                k = kegs // len(picks) + (1 if i < kegs % len(picks) else 0)
                if k <= 0:
                    continue
                need = k * 30
                if stock[sku] < need:
                    continue
                stock[sku] -= need
                ws_rows.append({
                    "date": d.isoformat(), "account_id": acc, "account": accname,
                    "sku": sku, "beer": BEER[sku].name, "kegs_30l": k,
                    "litres": need, "price_per_keg_inr": BEER[sku].keg_30l,
                    "revenue_inr": k * BEER[sku].keg_30l,
                    "cogs_inr": round(need * BEER[sku].cogs_l, 0),
                })

    covers = int(round(day_covers))
    footfall_rows.append({
        "date": d.isoformat(), "weekday": d.strftime("%a"),
        "covers": covers,
        "is_dry_day": "yes" if dry else "no",
        "festival": fest or "",
        "ipl_window": "yes" if is_ipl(d) else "no",
    })
    d += timedelta(days=1)

# ---------------------------------------------------------------------------
# Social posts: engagement is NOT aligned with margin. That is the point.
# ---------------------------------------------------------------------------
POST_TYPES = [
    ("brew education", 1.00, 0.9),
    ("food pairing", 1.10, 1.0),
    ("behind the scenes", 0.95, 0.85),
    ("event announcement", 1.35, 1.4),
    ("price offer", 2.65, 2.2),      # highest engagement, worst for margin
    ("new beer launch", 1.55, 1.5),
]
social_rows = []
d = START
pid = 0
while d <= END:
    if d.weekday() in (0, 2, 4, 5):
        pid += 1
        if d.year == 2026 and d.month in (2, 3, 4):
            tname, emul, fmul = random.choices(POST_TYPES, weights=[1, 1, 1, 1, 5, 1])[0]
        else:
            tname, emul, fmul = random.choices(POST_TYPES, weights=[2, 2, 2, 1, 1, 1])[0]
        reach = int(random.uniform(2400, 7200) * (1.25 if d.weekday() in (4, 5) else 1.0))
        eng = int(reach * random.uniform(0.028, 0.062) * emul)
        social_rows.append({
            "post_id": f"P{pid:04d}", "date": d.isoformat(),
            "platform": random.choice(["Instagram", "Instagram", "Instagram", "Facebook"]),
            "post_type": tname,
            "reach": reach, "engagements": eng,
            "saves": int(eng * random.uniform(0.05, 0.14)),
            "profile_taps": int(eng * random.uniform(0.08, 0.2)),
            "mentions_price_or_discount": "yes" if tname == "price offer" else "no",
            "mentions_alcohol_directly": "yes" if tname in ("price offer", "new beer launch") else "no",
        })
    d += timedelta(days=1)

# ---------------------------------------------------------------------------
# Purchases: derived from the brew schedule via recipes, lead time aware
# ---------------------------------------------------------------------------
need = {}
for b in batches:
    bd = date.fromisoformat(b["brew_date"])
    for mcode, per_hl in RECIPES[b["sku"]]:
        qty = per_hl * b["batch_size_hl"]
        lead = MAT[mcode][4]
        order_by = bd - timedelta(days=lead)
        key = (month_key(order_by), mcode)
        need[key] = need.get(key, 0.0) + qty

purchase_rows = []
po = 0
for (mk, mcode) in sorted(need):
    qty = need[(mk, mcode)]
    _, name, unit, cost, lead, bag, supplier = MAT[mcode]
    bags = max(1, int(-(-qty // bag)))          # round up to whole bags
    ordered = bags * bag
    y, m = int(mk[:4]), int(mk[5:])
    od = date(y, m, random.randint(2, 10))
    if od < START - timedelta(days=90):
        continue
    po += 1
    purchase_rows.append({
        "po_number": f"PO{po:04d}", "order_date": od.isoformat(),
        "expected_date": (od + timedelta(days=lead)).isoformat(),
        "material_code": mcode, "material": name, "supplier": supplier,
        "quantity": round(ordered, 1), "unit": unit,
        "unit_cost_inr": cost, "line_total_inr": round(ordered * cost, 0),
        "lead_time_days": lead,
        "consumed_by_recipe_qty": round(qty, 1),
    })

# closing stock at 2026-06-30: over-ordering leaves pilsner malt long,
# which is the supplier-seat trap once the room cuts the lager.
closing = {}
for r in purchase_rows:
    closing[r["material_code"]] = closing.get(r["material_code"], 0.0) + r["quantity"]
consumed = {}
for b in batches:
    for mcode, per_hl in RECIPES[b["sku"]]:
        consumed[mcode] = consumed.get(mcode, 0.0) + per_hl * b["batch_size_hl"]

# ---------------------------------------------------------------------------
# Roster: the manager's physical constraint
# ---------------------------------------------------------------------------
roster_rows = []
d = START
while d <= END:
    wd = d.weekday()
    if d in DRY_DAYS:
        foh = 0
    elif wd in (4, 5):
        foh = 4
    elif wd == 6:
        foh = 3
    elif wd == 3:
        foh = 2
    else:
        foh = 1            # Mon, Tue, Wed: ONE bartender
    roster_rows.append({
        "date": d.isoformat(), "weekday": d.strftime("%a"),
        "bar_staff": foh, "kitchen_staff": max(1, foh - 1),
        "brewery_staff": 2 if wd < 5 else 1,
        "max_covers_served": foh * 42,
    })
    d += timedelta(days=1)

# ---------------------------------------------------------------------------
# Keg and cold room capacity: the other manager constraint
# ---------------------------------------------------------------------------
keg_rows = [
    {"asset": "Cold room keg slots", "capacity": 14, "unit": "kegs 30L",
     "note": "Hard ceiling. Anything beyond this sits warm in the corridor."},
    {"asset": "Tap lines", "capacity": 8, "unit": "taps",
     "note": "8 taps, so at most 8 SKUs pouring at once."},
    {"asset": "Keg fleet owned", "capacity": 96, "unit": "kegs 30L",
     "note": "About 40 are out with wholesale accounts at any time."},
    {"asset": "Bright tank", "capacity": 20, "unit": "hL",
     "note": "One only. A second SKU cannot be carbonated in parallel."},
]

# ---------------------------------------------------------------------------
# Write CSVs
# ---------------------------------------------------------------------------
def write(name: str, rows: List[dict], fields: Optional[List[str]] = None) -> None:
    path = os.path.join(OUT, name)
    if not rows:
        print("  SKIP (empty):", name)
        return
    fields = fields or list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
    print(f"  {name:26s} {len(rows):>6d} rows")


print("Deccan Draught Co. dataset")
print("period:", START, "to", END)

beer_rows = []
for bb in BEERS:
    code, name, style, og, fg, abv, ibu, td, cogs, pint, keg = bb
    price_l_taproom = pint / 0.5
    gm_l = price_l_taproom - cogs
    vol_hl = 10 if code in ("KS", "HH") else 20
    contrib_batch = gm_l * vol_hl * 100
    beer_rows.append({
        "sku": code, "beer": name, "style": style,
        "target_og": og, "target_fg": fg, "abv_pct": abv, "ibu": ibu,
        "tank_days": td, "batch_size_hl": vol_hl,
        "cogs_per_litre_inr": cogs,
        "taproom_price_500ml_inr": pint,
        "taproom_price_per_litre_inr": round(price_l_taproom, 0),
        "wholesale_price_30l_keg_inr": keg,
        "gross_margin_per_litre_inr": round(gm_l, 0),
        "contribution_per_batch_inr": round(contrib_batch, 0),
        "contribution_per_tank_day_inr": round(contrib_batch / td, 0),
        "requires_lagering_tank": "yes" if code == "DL" else "no",
    })

write("beers.csv", beer_rows)
write("tanks.csv", [{"tank_id": t, "capacity_hl": c, "lagering_capable": l,
                     "note": "glycol jacket, holds 4C" if l == "yes" else "ambient jacket only"}
                    for t, c, l in TANKS])
write("recipes.csv", [{"sku": s, "material_code": m, "material": MAT[m][1],
                       "qty_per_hl": q, "unit": MAT[m][2]}
                      for s, items in RECIPES.items() for m, q in items])
write("materials.csv", [{"material_code": m, "material": n, "unit": u,
                         "unit_cost_inr": c, "lead_time_days": l, "bag_size": b,
                         "supplier": s,
                         "purchased_to_date": round(closing.get(m, 0), 1),
                         "consumed_to_date": round(consumed.get(m, 0), 1),
                         "closing_stock_2026_06_30": round(closing.get(m, 0) - consumed.get(m, 0), 1)}
                        for m, n, u, c, l, b, s in MATERIALS])
write("batches.csv", batches)
write("tank_occupancy.csv", occupancy)
write("pos_sales.csv", pos_rows)
write("wholesale_orders.csv", ws_rows)
write("footfall.csv", footfall_rows)
write("social_posts.csv", social_rows)
write("purchases.csv", purchase_rows)
write("roster.csv", roster_rows)
write("capacity_limits.csv", keg_rows)
write("stockouts.csv", stockouts)
write("calendar.csv",
      [{"date": dd.isoformat(),
        "dry_day": "yes" if dd in DRY_DAYS else "no",
        "festival": FESTIVALS.get(dd, ""),
        "ipl_window": "yes" if is_ipl(dd) else "no"}
       for dd in [START + timedelta(days=i) for i in range((END - START).days + 1)]
       if dd in DRY_DAYS or dd in FESTIVALS or is_ipl(dd)])

# ---------------------------------------------------------------------------
# Reconciliation report: prove the dataset holds together
# ---------------------------------------------------------------------------
print("\nreconciliation")
packaged = {}
for b in batches:
    packaged[b["sku"]] = packaged.get(b["sku"], 0) + b["packaged_litres"]
sold = {}
for r in pos_rows:
    sold[r["sku"]] = sold.get(r["sku"], 0) + r["litres_sold"]
for r in ws_rows:
    sold[r["sku"]] = sold.get(r["sku"], 0) + r["litres"]

ok = True
for sku in BEER:
    p, s = packaged.get(sku, 0), sold.get(sku, 0)
    flag = "OK " if s <= p + 0.5 else "FAIL"
    if s > p + 0.5:
        ok = False
    print(f"  {flag} {sku} packaged {p:>8.0f} L  sold {s:>8.0f} L  closing {p - s:>7.0f} L")

# tank double-booking check
by_tank = {}
for o in occupancy:
    by_tank.setdefault(o["tank"], []).append(o)
clashes = 0
for t, os_ in by_tank.items():
    os_.sort(key=lambda x: x["occupied_from"])
    for a, b in zip(os_, os_[1:]):
        if b["occupied_from"] <= a["occupied_to"]:
            clashes += 1
print(f"  {'OK ' if clashes == 0 else 'FAIL'} tank double-bookings: {clashes}")

# purchases must precede the brews they feed
late = sum(1 for r in purchase_rows if r["expected_date"] > "2026-06-30")
print(f"  OK  purchase orders: {len(purchase_rows)}, arriving after period end: {late}")
print(f"  OK  batches: {len(batches)}, dumped: {len(DUMPED)}, stockout days logged: {len(stockouts)}")
tap_l = sum(float(r["litres_sold"]) for r in pos_rows)
ws_l = sum(float(r["litres"]) for r in ws_rows)
mix = tap_l / (tap_l + ws_l) * 100
print(f"  OK  channel mix: taproom {mix:.0f}% / wholesale {100 - mix:.0f}% "
      f"({tap_l:,.0f} L / {ws_l:,.0f} L)")
print(f"  OK  opening inventory seeded: {sum(OPENING_STOCK.values()):,.0f} L "
      f"(about 18 days cover, year 4 brewery)")
print(f"\n{'RECONCILED' if ok and clashes == 0 else 'CHECK FAILED'}  ->  {OUT}")
