# The prompt pack

Every prompt used in the workshop, in plain language, ready to paste against your
own numbers.

**Start with PROMPT-STRUCTURE.md.** It is the four-line card you were handed at the
beginning of the session. Every prompt below is those four lines with a different
file attached.

**Where to paste these.** The session used Claude, in three places: Claude Cowork
for the longer jobs, the Claude app on a phone or in a browser, and Claude desktop
on a laptop. The same prompts work in all three.

**How to use them.** Attach your file first, then paste the prompt. Do not describe
your data in words and hope the model imagines it. The whole method is that the
model reads your evidence instead of inventing an answer.

**Swap in your own files.** Where a prompt names `pos_sales.csv`, use your own POS
export. Column names will differ. Say so in one line and the model will map them:
*"In my file, litres sold is called Qty_Ltr and the date column is TxnDate."*

**One thread per decision.** Not one thread per week. See CREDIT-HABITS.md.

**Before you upload anything real, read DATA-SECURITY.md.** One page, three minutes
to act on.

---

# Use case 1. What do we brew next?

**The outcome: rank by contribution per tank-day, not by volume.**

### Step one. The production plan

**Attach:** `pos_sales.csv`, `wholesale_orders.csv`, `batches.csv`, `beers.csv`

```
You are helping me plan next month's production at a craft brewery.

Attached are 18 months of taproom sales, wholesale orders, brew records and the
beer master list.

Work out, for each beer:
1. Litres sold per month across both channels, and the trend over the last
   6 months against the same months a year earlier.
2. Which months had unmet demand, meaning sales dropped while the beer was
   out of stock rather than because demand fell.
3. How many batches of each beer I need next month to cover forecast demand
   plus 3 weeks of cover.

Then give me a draft production plan for August 2026 as a table: beer, number of
batches, litres, and the reason.

Important: tell me which numbers you are confident in and which are thin. If the
history for a beer is too short or too seasonal to forecast, say so instead of
guessing.
```

### Step two. The tank check that changes the answer

```
Now check that plan against the tank farm. Attached is tank_occupancy.csv and
tanks.csv. Every batch occupies one fermenter for its full tank days.

Tell me whether my August plan physically fits in 8 fermenters, given that only
FV1, FV2 and FV3 can hold lagering temperature. If it does not fit, tell me what
has to give.
```

### Step three. The ranking nobody runs

**Attach:** `pos_sales.csv`, `wholesale_orders.csv`, `beers.csv`

```
Attached are 18 months of taproom and wholesale sales, and a beer master list with
cost per litre, price and tank days for each beer.

Rank my beers four different ways:
1. Litres sold
2. Gross revenue
3. Contribution, meaning revenue minus cost of goods
4. Contribution per tank day, meaning contribution per batch divided by the days
   that batch occupies a fermenter

Show all four ranks in one table so I can see where a beer moves between them.

Then tell me in plain language: which beer looks like my best seller but is not
my best earner, and how big is the gap.
```

**The follow-up:**

```
Now tell me what happens to monthly contribution if I brew one fewer batch of my
worst performer on contribution per tank day, and one more of my best. Use my
actual volumes and prices. Show the arithmetic so I can check it.
```

---

# Use case 2. Can you actually pour it?

**The outcome: test the plan against physical capacity before you commit.**

**Attach:** `footfall.csv`, `roster.csv`, `capacity_limits.csv`, `calendar.csv`,
plus the plan from use case 1

```
Attached are daily footfall, the staff roster, my physical capacity limits, and the
India calendar of dry days, festivals and IPL windows.

Build me a tap schedule and staffing view for next month that answers:
1. Which days will be busiest, based on weekday pattern, festivals and IPL.
2. Which of those days are currently rostered with only one bar staff member.
3. Whether the beers in the production plan can physically be on tap at the same
   time, given 8 tap lines and 14 cold room keg slots.

Be explicit about anything in the plan that does not fit the physical limits. Do
not silently assume I can add taps, staff or cold storage.
```

**The follow-up:**

```
Give me the three changes to the roster or the tap list that would recover the
most lost revenue, ranked, with the reasoning. Only suggest changes that fit
inside the capacity limits in the attached file.
```

---

# Use case 3. How do you sell it?

**The outcome: hand the model the constraints it cannot see.**

**Attach:** `social_posts.csv`, `footfall.csv`, `pos_sales.csv`, `calendar.csv`

```
Attached are 18 months of social posts with reach and engagement, daily footfall,
and daily sales.

Work out:
1. Engagement rate by post type.
2. Whether footfall in the 3 days after each post type is measurably higher than
   the baseline for that weekday.
3. Whether the days with the highest footfall were also the days with the highest
   contribution, or whether discounting cancelled it out.

Then tell me which post type actually brings paying people through the door, as
opposed to which one gets the most likes. If those are different, say so directly.
```

**The follow-up, and this one is the whole point:**

```
Two of my columns flag whether a post mentions price or promotes alcohol directly.
Indian advertising rules restrict direct alcohol promotion.

Re-rank the post types, excluding anything that would breach those rules. Then
propose a content plan for next month using only compliant formats, with a
measurable target for each post that ties back to footfall rather than to
engagement.
```

---

# Bonus. The two we did not have time for

## The malt order, which was the quiz

**Attach:** `purchases.csv`, `materials.csv`, `recipes.csv`, `batches.csv`

```
I supply raw materials to a brewery. Attached are their purchase history, the
material master with lead times, the recipes per hectolitre, and their brew records.

Work out:
1. Consumption per material per month, derived from batches and recipes.
2. Their reorder pattern: how many days of cover they typically hold, per material.
3. Which materials they are likely to reorder in the next 60 days, and roughly
   when, given lead times.

Give me a call list ranked by urgency, with the quantity I should expect and the
date I should call.
```

**The follow-up that breaks the forecast, on purpose:**

```
Now assume the brewery changes its plan: it cuts its lager volume in half and
puts that tank time into its wheat beer instead.

Using recipes.csv, recalculate which materials that changes and by how much. Tell
me specifically what happens to the material my forecast said they were about to
reorder, and whether anything with a long lead time is now needed sooner than it
can arrive.
```

Run those two in order and the quiz answer is in front of you, with the arithmetic
under it.

## Stopping the credit bleed

See CREDIT-HABITS.md. Four habits, one page. The short version: one thread per
decision, attach the file once, and ask for the analysis rather than the essay.

---

## The prompt that goes on top of all of them

Paste this before any of the above if you want the model to behave itself:

```
Ground every number you give me in the attached files. If a number is not in the
data, say "not in the data" instead of estimating it. If two files disagree, show
me the disagreement rather than picking one. Where you make an assumption, put it
in a list at the end labelled Assumptions.
```

That paragraph is the difference between an answer engine and an evidence engine.

---

## What the model will get wrong

It will happen in your data too, so watch for it:

1. **It ignores physical limits** unless you attach them. Tanks, kegs, taps and
   staff do not exist in a sales file.
2. **It treats the top seller as the best product.** Volume is the easiest number
   to see and the least useful on its own.
3. **It reads a stockout as falling demand.** Sales went down, so it concludes
   people stopped wanting it. Always give it the stock position too.
4. **It optimises engagement, not footfall,** because engagement is the number in
   the file and footfall is one join away.
5. **It assumes the past pattern continues** after you have just decided to change
   the plan.

Every one of those is a place where you overrule it. That is the job the software
cannot do.
