# Four habits that stop the credit bleed

One page. This is the complaint everybody in the room has and nobody has answered.

Every AI tool charges you for the whole conversation, every time you send a message.
Not just your new question, the entire thread that came before it. A thread that has
run for two weeks costs many times what the same question costs in a fresh thread.
That is why the limit runs out faster the longer you work.

---

## 1. One thread per decision, not one thread per week

**The mistake:** a single running conversation called "brewery stuff" that you come
back to for a month.

**Why it costs you:** by message fifty, every question you ask carries forty-nine
previous answers along with it. You pay for all of them again.

**Do this instead:** start a new thread for each real decision. "August production
plan" is a thread. "Why did wheat drop in March" is a different thread. Close them
when the decision is made.

---

## 2. Attach the file once, then stay in that thread

**The mistake:** re-uploading the same sales export every time you have a new
question about it.

**Why it costs you:** the file is charged for on every message that carries it, and
re-attaching resets nothing.

**Do this instead:** attach once at the start, then ask as many questions as you
like inside that thread. When you move to a genuinely different question, start a
new thread and attach again.

---

## 3. Use a saved project for anything you repeat monthly

**The mistake:** rewriting the same production planning prompt from scratch every
month, including re-explaining what your columns mean.

**Why it costs you:** you pay for re-establishing context that has not changed since
last month.

**Do this instead:** most tools let you save a project or a custom instruction with
your file layout and your standing preferences in it. Put your column names, your
tank list and your price list there once. Then each month is one short question.

---

## 4. Ask for the analysis, not the essay

**The mistake:** "tell me everything you can about my sales data."

**Why it costs you twice:** you pay for a long answer, and then you pay again in
your own time reading nine paragraphs to find the one number you needed.

**Do this instead:** ask for the output shape you want. "Give me a table, six rows,
beer name and contribution per tank day, ranked. No commentary." If you want the
reasoning, ask for it afterwards, and only for the row that surprised you.

---

## The test

If you cannot say which decision a thread is for, close it. It is costing you money
to stay open and it is making the model's answers worse, because a long thread
carries every wrong turn you took in it.

---

## One more thing that is not about cost

Long threads make the answers worse, not just dearer. A thread that contains three
abandoned approaches and a wrong assumption you corrected halfway through will keep
dragging that history into every new answer. Starting fresh is often the fix for a
model that has started producing rubbish.
